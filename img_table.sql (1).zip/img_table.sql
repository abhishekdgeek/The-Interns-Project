-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 26, 2015 at 10:23 ?????????
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `image`
--

-- --------------------------------------------------------

--
-- Table structure for table `img_table`
--

CREATE TABLE IF NOT EXISTS `img_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blur_img` varchar(60) NOT NULL,
  `org_img` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=101 ;

--
-- Dumping data for table `img_table`
--

INSERT INTO `img_table` (`id`, `blur_img`, `org_img`) VALUES
(1, './blur images/test-app-400x400-blur_1.png', './images/test-app-400x400_1.png'),
(2, './blur images/test-app-400x400-blur_2.png', './images/test-app-400x400_2.png'),
(3, './blur images/test-app-400x400-blur_3.png', './images/test-app-400x400_3.png'),
(4, './blur images/test-app-400x400-blur_4.png', './images/test-app-400x400_4.png'),
(5, './blur images/test-app-400x400-blur_5.png', './images/test-app-400x400_5.png'),
(6, './blur images/test-app-400x400-blur_6.png', './images/test-app-400x400_6.png'),
(7, './blur images/test-app-400x400-blur_7.png', './images/test-app-400x400_7.png'),
(8, './blur images/test-app-400x400-blur_8.png', './images/test-app-400x400_8.png'),
(9, './blur images/test-app-400x400-blur_9.png', './images/test-app-400x400_9.png'),
(10, './blur images/test-app-400x400-blur_10.png', './images/test-app-400x400_10.png'),
(11, './blur images/test-app-400x400-blur_11.png', './images/test-app-400x400_11.png'),
(12, './blur images/test-app-400x400-blur_12.png', './images/test-app-400x400_12.png'),
(13, './blur images/test-app-400x400-blur_13.png', './images/test-app-400x400_13.png'),
(14, './blur images/test-app-400x400-blur_14.png', './images/test-app-400x400_14.png'),
(15, './blur images/test-app-400x400-blur_15.png', './images/test-app-400x400_15.png'),
(16, './blur images/test-app-400x400-blur_16.png', './images/test-app-400x400_16.png'),
(17, './blur images/test-app-400x400-blur_17.png', './images/test-app-400x400_17.png'),
(18, './blur images/test-app-400x400-blur_18.png', './images/test-app-400x400_18.png'),
(19, './blur images/test-app-400x400-blur_19.png', './images/test-app-400x400_19.png'),
(20, './blur images/test-app-400x400-blur_20.png', './images/test-app-400x400_20.png'),
(21, './blur images/test-app-400x400-blur_21.png', './images/test-app-400x400_21.png'),
(22, './blur images/test-app-400x400-blur_22.png', './images/test-app-400x400_22.png'),
(23, './blur images/test-app-400x400-blur_23.png', './images/test-app-400x400_23.png'),
(24, './blur images/test-app-400x400-blur_24.png', './images/test-app-400x400_24.png'),
(25, './blur images/test-app-400x400-blur_25.png', './images/test-app-400x400_25.png'),
(26, './blur images/test-app-400x400-blur_26.png', './images/test-app-400x400_26.png'),
(27, './blur images/test-app-400x400-blur_27.png', './images/test-app-400x400_27.png'),
(28, './blur images/test-app-400x400-blur_28.png', './images/test-app-400x400_28.png'),
(29, './blur images/test-app-400x400-blur_29.png', './images/test-app-400x400_29.png'),
(30, './blur images/test-app-400x400-blur_30.png', './images/test-app-400x400_30.png'),
(31, './blur images/test-app-400x400-blur_31.png', './images/test-app-400x400_31.png'),
(32, './blur images/test-app-400x400-blur_32.png', './images/test-app-400x400_32.png'),
(33, './blur images/test-app-400x400-blur_33.png', './images/test-app-400x400_33.png'),
(34, './blur images/test-app-400x400-blur_34.png', './images/test-app-400x400_34.png'),
(35, './blur images/test-app-400x400-blur_35.png', './images/test-app-400x400_35.png'),
(36, './blur images/test-app-400x400-blur_36.png', './images/test-app-400x400_36.png'),
(37, './blur images/test-app-400x400-blur_37.png', './images/test-app-400x400_37.png'),
(38, './blur images/test-app-400x400-blur_38.png', './images/test-app-400x400_38.png'),
(39, './blur images/test-app-400x400-blur_39.png', './images/test-app-400x400_39.png'),
(40, './blur images/test-app-400x400-blur_40.png', './images/test-app-400x400_40.png'),
(41, './blur images/test-app-400x400-blur_41.png', './images/test-app-400x400_41.png'),
(42, './blur images/test-app-400x400-blur_42.png', './images/test-app-400x400_42.png'),
(43, './blur images/test-app-400x400-blur_43.png', './images/test-app-400x400_43.png'),
(44, './blur images/test-app-400x400-blur_44.png', './images/test-app-400x400_44.png'),
(45, './blur images/test-app-400x400-blur_45.png', './images/test-app-400x400_45.png'),
(46, './blur images/test-app-400x400-blur_46.png', './images/test-app-400x400_46.png'),
(47, './blur images/test-app-400x400-blur_47.png', './images/test-app-400x400_47.png'),
(48, './blur images/test-app-400x400-blur_48.png', './images/test-app-400x400_48.png'),
(49, './blur images/test-app-400x400-blur_49.png', './images/test-app-400x400_49.png'),
(50, './blur images/test-app-400x400-blur_50.png', './images/test-app-400x400_50.png'),
(51, './blur images/test-app-400x400-blur_51.png', './images/test-app-400x400_51.png'),
(52, './blur images/test-app-400x400-blur_52.png', './images/test-app-400x400_52.png'),
(53, './blur images/test-app-400x400-blur_53.png', './images/test-app-400x400_53.png'),
(54, './blur images/test-app-400x400-blur_54.png', './images/test-app-400x400_54.png'),
(55, './blur images/test-app-400x400-blur_55.png', './images/test-app-400x400_55.png'),
(56, './blur images/test-app-400x400-blur_56.png', './images/test-app-400x400_56.png'),
(57, './blur images/test-app-400x400-blur_57.png', './images/test-app-400x400_57.png'),
(58, './blur images/test-app-400x400-blur_58.png', './images/test-app-400x400_58.png'),
(59, './blur images/test-app-400x400-blur_59.png', './images/test-app-400x400_59.png'),
(60, './blur images/test-app-400x400-blur_60.png', './images/test-app-400x400_60.png'),
(61, './blur images/test-app-400x400-blur_61.png', './images/test-app-400x400_61.png'),
(62, './blur images/test-app-400x400-blur_62.png', './images/test-app-400x400_62.png'),
(63, './blur images/test-app-400x400-blur_63.png', './images/test-app-400x400_63.png'),
(64, './blur images/test-app-400x400-blur_64.png', './images/test-app-400x400_64.png'),
(65, './blur images/test-app-400x400-blur_65.png', './images/test-app-400x400_65.png'),
(66, './blur images/test-app-400x400-blur_66.png', './images/test-app-400x400_66.png'),
(67, './blur images/test-app-400x400-blur_67.png', './images/test-app-400x400_67.png'),
(68, './blur images/test-app-400x400-blur_68.png', './images/test-app-400x400_68.png'),
(69, './blur images/test-app-400x400-blur_69.png', './images/test-app-400x400_69.png'),
(70, './blur images/test-app-400x400-blur_70.png', './images/test-app-400x400_70.png'),
(71, './blur images/test-app-400x400-blur_71.png', './images/test-app-400x400_71.png'),
(72, './blur images/test-app-400x400-blur_72.png', './images/test-app-400x400_72.png'),
(73, './blur images/test-app-400x400-blur_73.png', './images/test-app-400x400_73.png'),
(74, './blur images/test-app-400x400-blur_74.png', './images/test-app-400x400_74.png'),
(75, './blur images/test-app-400x400-blur_75.png', './images/test-app-400x400_75.png'),
(76, './blur images/test-app-400x400-blur_76.png', './images/test-app-400x400_76.png'),
(77, './blur images/test-app-400x400-blur_77.png', './images/test-app-400x400_77.png'),
(78, './blur images/test-app-400x400-blur_78.png', './images/test-app-400x400_78.png'),
(79, './blur images/test-app-400x400-blur_79.png', './images/test-app-400x400_79.png'),
(80, './blur images/test-app-400x400-blur_80.png', './images/test-app-400x400_80.png'),
(81, './blur images/test-app-400x400-blur_81.png', './images/test-app-400x400_81.png'),
(82, './blur images/test-app-400x400-blur_82.png', './images/test-app-400x400_82.png'),
(83, './blur images/test-app-400x400-blur_83.png', './images/test-app-400x400_83.png'),
(84, './blur images/test-app-400x400-blur_84.png', './images/test-app-400x400_84.png'),
(85, './blur images/test-app-400x400-blur_85.png', './images/test-app-400x400_85.png'),
(86, './blur images/test-app-400x400-blur_86.png', './images/test-app-400x400_86.png'),
(87, './blur images/test-app-400x400-blur_87.png', './images/test-app-400x400_87.png'),
(88, './blur images/test-app-400x400-blur_88.png', './images/test-app-400x400_88.png'),
(89, './blur images/test-app-400x400-blur_89.png', './images/test-app-400x400_89.png'),
(90, './blur images/test-app-400x400-blur_90.png', './images/test-app-400x400_90.png'),
(91, './blur images/test-app-400x400-blur_91.png', './images/test-app-400x400_91.png'),
(92, './blur images/test-app-400x400-blur_92.png', './images/test-app-400x400_92.png'),
(93, './blur images/test-app-400x400-blur_93.png', './images/test-app-400x400_93.png'),
(94, './blur images/test-app-400x400-blur_94.png', './images/test-app-400x400_94.png'),
(95, './blur images/test-app-400x400-blur_95.png', './images/test-app-400x400_95.png'),
(96, './blur images/test-app-400x400-blur_96.png', './images/test-app-400x400_96.png'),
(97, './blur images/test-app-400x400-blur_97.png', './images/test-app-400x400_97.png'),
(98, './blur images/test-app-400x400-blur_98.png', './images/test-app-400x400_98.png'),
(99, './blur images/test-app-400x400-blur_99.png', './images/test-app-400x400_99.png'),
(100, './blur images/test-app-400x400-blur_100.png', './images/test-app-400x400_100.png');
